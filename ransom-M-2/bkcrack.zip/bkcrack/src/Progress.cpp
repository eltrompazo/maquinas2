#include "Progress.hpp"

Progress::Progress(std::ostream& os)
: m_os{os}
{}
