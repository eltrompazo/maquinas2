Documentation {#index}
=============

Welcome to the documentation.

\if not_doxygen

**Use doxygen to generate the HTML documentation.**

\endif
